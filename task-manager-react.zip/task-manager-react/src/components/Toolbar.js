import React from 'react';
import './Toolbar.css';

const FILTERS = [
  { id: 'all',         label: 'All' },
  { id: 'todo',        label: 'To Do' },
  { id: 'in-progress', label: 'In Progress' },
  { id: 'completed',   label: 'Done' },
];

export default function Toolbar({ search, setSearch, filter, setFilter }) {
  return (
    <div className="toolbar">
      <div className="tb-search">
        <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2">
          <circle cx="9" cy="9" r="5"/><path d="M16 16l-3.5-3.5"/>
        </svg>
        <input
          type="text"
          placeholder="Search tasks…"
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="tb-input"
        />
        {search && (
          <button className="tb-clear" onClick={() => setSearch('')}>✕</button>
        )}
      </div>

      <div className="tb-filters">
        {FILTERS.map(f => (
          <button
            key={f.id}
            className={`tb-filter ${filter === f.id ? 'active' : ''}`}
            onClick={() => setFilter(f.id)}
          >
            {f.label}
          </button>
        ))}
      </div>
    </div>
  );
}
