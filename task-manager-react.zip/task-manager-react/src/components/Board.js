import React from 'react';
import TaskCard from './TaskCard';
import './Board.css';

const COLS = [
  { id: 'todo',        label: 'To Do',       color: 'var(--blue)' },
  { id: 'in-progress', label: 'In Progress', color: 'var(--orange)' },
  { id: 'completed',   label: 'Completed',   color: 'var(--accent)' },
];

export default function Board({ tasks, onEdit, onDelete, onMove, onAdd }) {
  return (
    <div className="board">
      {COLS.map(col => {
        const colTasks = tasks.filter(t => t.status === col.id);
        return (
          <div className="col" key={col.id}>
            <div className="col-header">
              <span className="col-dot" style={{ background: col.color }} />
              <span className="col-title">{col.label}</span>
              <span className="col-count">{colTasks.length}</span>
              <button className="col-add" onClick={() => onAdd(col.id)} title="Add task">
                <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.4">
                  <path d="M10 4v12M4 10h12"/>
                </svg>
              </button>
            </div>

            <div className="col-body">
              {colTasks.length === 0
                ? <EmptyState />
                : colTasks.map(t => (
                    <TaskCard
                      key={t.id}
                      task={t}
                      onEdit={() => onEdit(t)}
                      onDelete={() => onDelete(t.id)}
                      onMove={onMove}
                    />
                  ))
              }
            </div>
          </div>
        );
      })}
    </div>
  );
}

function EmptyState() {
  return (
    <div className="empty">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2">
        <rect x="3" y="3" width="18" height="18" rx="3"/>
        <path d="M9 12h6M9 8h6M9 16h3"/>
      </svg>
      <p>No tasks here</p>
    </div>
  );
}
