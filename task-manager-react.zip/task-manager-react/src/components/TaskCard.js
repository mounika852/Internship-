import React, { useState, useRef, useEffect } from 'react';
import './TaskCard.css';

const PRIORITY_COLORS = { low: 'var(--blue)', medium: 'var(--orange)', high: 'var(--red)' };
const STATUS_MOVES = {
  'todo':        [{ status: 'in-progress', label: 'Move to In Progress', icon: '⚡' }, { status: 'completed', label: 'Mark Complete', icon: '✅' }],
  'in-progress': [{ status: 'todo', label: 'Move to To Do', icon: '🕐' },              { status: 'completed', label: 'Mark Complete', icon: '✅' }],
  'completed':   [{ status: 'todo', label: 'Move to To Do', icon: '🕐' },              { status: 'in-progress', label: 'Move to In Progress', icon: '⚡' }],
};

export default function TaskCard({ task, onEdit, onDelete, onMove }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);

  // close menu on outside click
  useEffect(() => {
    if (!menuOpen) return;
    const handler = e => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [menuOpen]);

  const date = new Date(task.createdAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

  return (
    <div className="task-card">
      <div className="tc-top">
        <p className={`tc-title ${task.status === 'completed' ? 'done' : ''}`}>{task.title}</p>
        <div className="tc-menu-wrap" ref={menuRef}>
          <button className="tc-menu-btn" onClick={() => setMenuOpen(v => !v)}>⋯</button>
          {menuOpen && (
            <div className="tc-menu">
              <button className="tc-mi" onClick={() => { onEdit(); setMenuOpen(false); }}>
                ✏️ Edit
              </button>
              {STATUS_MOVES[task.status].map(m => (
                <button key={m.status} className="tc-mi" onClick={() => { onMove(task.id, m.status); setMenuOpen(false); }}>
                  {m.icon} {m.label}
                </button>
              ))}
              <div className="tc-divider" />
              <button className="tc-mi danger" onClick={() => { onDelete(); setMenuOpen(false); }}>
                🗑 Delete
              </button>
            </div>
          )}
        </div>
      </div>

      {task.description && (
        <p className="tc-desc">{task.description}</p>
      )}

      <div className="tc-footer">
        <span
          className="tc-priority"
          style={{ color: PRIORITY_COLORS[task.priority], background: PRIORITY_COLORS[task.priority] + '18' }}
        >
          {task.priority}
        </span>
        <span className="tc-date">{date}</span>
      </div>
    </div>
  );
}
