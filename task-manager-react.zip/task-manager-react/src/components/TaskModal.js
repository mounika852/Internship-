import React, { useState, useEffect, useRef } from 'react';
import './TaskModal.css';

export default function TaskModal({ task, defaultStatus, onSave, onClose }) {
  const [title,    setTitle]    = useState(task?.title       || '');
  const [desc,     setDesc]     = useState(task?.description || '');
  const [status,   setStatus]   = useState(task?.status      || defaultStatus);
  const [priority, setPriority] = useState(task?.priority    || 'medium');
  const [error,    setError]    = useState('');
  const titleRef = useRef(null);

  useEffect(() => {
    setTimeout(() => titleRef.current?.focus(), 60);
    const onKey = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const handleSave = () => {
    if (!title.trim()) { setError('Title is required'); return; }
    onSave({ title: title.trim(), description: desc.trim(), status, priority });
  };

  const handleKeyDown = e => {
    if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') handleSave();
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" onKeyDown={handleKeyDown}>
        <div className="modal-header">
          <h2 className="modal-title">{task ? 'Edit Task' : 'New Task'}</h2>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        {/* Title */}
        <div className="form-group">
          <label className="form-label">Title <span className="required">*</span></label>
          <input
            ref={titleRef}
            className={`form-input ${error ? 'has-error' : ''}`}
            type="text"
            placeholder="Enter task title…"
            value={title}
            onChange={e => { setTitle(e.target.value); setError(''); }}
          />
          {error && <p className="form-error">{error}</p>}
        </div>

        {/* Description */}
        <div className="form-group">
          <label className="form-label">Description</label>
          <textarea
            className="form-textarea"
            placeholder="Add more details (optional)…"
            value={desc}
            onChange={e => setDesc(e.target.value)}
            rows={3}
          />
        </div>

        {/* Status + Priority row */}
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Status</label>
            <select className="form-select" value={status} onChange={e => setStatus(e.target.value)}>
              <option value="todo">To Do</option>
              <option value="in-progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Priority</label>
            <select className="form-select" value={priority} onChange={e => setPriority(e.target.value)}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </select>
          </div>
        </div>

        {/* Priority visual picker */}
        <div className="priority-picker">
          {['low','medium','high'].map(p => (
            <button
              key={p}
              className={`pp-btn pp-${p} ${priority === p ? 'active' : ''}`}
              onClick={() => setPriority(p)}
              type="button"
            >
              {p === 'low' ? '🟦' : p === 'medium' ? '🟧' : '🔴'} {p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>

        <div className="modal-actions">
          <button className="modal-cancel" onClick={onClose}>Cancel</button>
          <button className="modal-save" onClick={handleSave}>
            {task ? 'Update Task' : 'Create Task'} →
          </button>
        </div>
      </div>
    </div>
  );
}
