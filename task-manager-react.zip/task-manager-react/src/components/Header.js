import React from 'react';
import './Header.css';

export default function Header({ onNew, onClearDone }) {
  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long', month: 'long', day: 'numeric', year: 'numeric'
  });

  return (
    <div className="header">
      <div className="header-left">
        <h1 className="header-title">My Tasks</h1>
        <p className="header-date">{today}</p>
      </div>
      <div className="header-right">
        <button className="hdr-btn ghost" onClick={onClearDone}>
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.2">
            <path d="M3 6h14M8 6V4h4v2M19 6l-1 12a2 2 0 01-2 2H4a2 2 0 01-2-2L1 6"/>
          </svg>
          Clear Done
        </button>
        <button className="hdr-btn primary" onClick={onNew}>
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M10 4v12M4 10h12"/>
          </svg>
          New Task
          <kbd>⌘K</kbd>
        </button>
      </div>
    </div>
  );
}
