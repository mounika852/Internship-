import React from 'react';
import './Toast.css';

const ICONS = { success: '✓', error: '✕', info: 'ℹ' };

export default function Toast({ msg, type }) {
  return (
    <div className={`toast toast-${type}`}>
      <span className="toast-icon">{ICONS[type]}</span>
      <span className="toast-msg">{msg}</span>
    </div>
  );
}
