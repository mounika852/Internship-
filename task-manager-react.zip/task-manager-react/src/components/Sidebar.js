import React from 'react';
import './Sidebar.css';

export default function Sidebar({ stats, filter, setFilter, priorityFilter, setPriorityFilter }) {
  const navItems = [
    { id: 'all',         label: 'All Tasks',    count: stats.total,    icon: <GridIcon /> },
    { id: 'todo',        label: 'To Do',        count: stats.todo,     icon: <ClockIcon /> },
    { id: 'in-progress', label: 'In Progress',  count: stats.progress, icon: <FlashIcon /> },
    { id: 'completed',   label: 'Completed',    count: stats.done,     icon: <CheckIcon /> },
  ];
  const priorities = [
    { id: 'high',   label: 'High',   color: 'var(--red)' },
    { id: 'medium', label: 'Medium', color: 'var(--orange)' },
    { id: 'low',    label: 'Low',    color: 'var(--blue)' },
  ];

  return (
    <aside className="sidebar">
      {/* Logo */}
      <div className="sb-logo">
        <div className="sb-logo-icon">
          <svg viewBox="0 0 20 20" fill="none" stroke="#000" strokeWidth="2.2">
            <path d="M4 5h12M4 9h8M4 13h10M4 17h6"/>
          </svg>
        </div>
        <span className="sb-logo-name">TaskFlow</span>
      </div>

      {/* Nav */}
      <nav className="sb-nav">
        <p className="sb-section-label">Workspace</p>
        {navItems.map(item => (
          <button
            key={item.id}
            className={`sb-btn ${filter === item.id && !priorityFilter ? 'active' : ''}`}
            onClick={() => setFilter(item.id)}
          >
            <span className="sb-btn-icon">{item.icon}</span>
            <span className="sb-btn-label">{item.label}</span>
            <span className="sb-badge">{item.count}</span>
          </button>
        ))}

        <p className="sb-section-label" style={{ marginTop: '20px' }}>Priority</p>
        {priorities.map(p => (
          <button
            key={p.id}
            className={`sb-btn ${priorityFilter === p.id ? 'active' : ''}`}
            onClick={() => setPriorityFilter(priorityFilter === p.id ? null : p.id)}
          >
            <span className="sb-dot" style={{ background: p.color }} />
            <span className="sb-btn-label">{p.label} Priority</span>
          </button>
        ))}
      </nav>

      {/* Footer */}
      <div className="sb-footer">
        <div className="sb-user">
          <div className="sb-avatar">JD</div>
          <div className="sb-user-info">
            <p className="sb-user-name">John Doe</p>
            <p className="sb-user-role">Developer</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

function GridIcon() {
  return <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8">
    <rect x="3" y="3" width="6" height="6" rx="1"/><rect x="11" y="3" width="6" height="6" rx="1"/>
    <rect x="3" y="11" width="6" height="6" rx="1"/><rect x="11" y="11" width="6" height="6" rx="1"/>
  </svg>;
}
function ClockIcon() {
  return <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8">
    <circle cx="10" cy="10" r="7"/><path d="M10 6v4l2.5 2.5"/>
  </svg>;
}
function FlashIcon() {
  return <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M11 3L5 11h6l-2 6 8-9h-6l2-5z"/>
  </svg>;
}
function CheckIcon() {
  return <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" strokeWidth="1.8">
    <path d="M5 10l4 4 6-6"/><circle cx="10" cy="10" r="7"/>
  </svg>;
}
