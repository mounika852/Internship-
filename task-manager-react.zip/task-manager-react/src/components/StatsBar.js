import React from 'react';
import './StatsBar.css';

export default function StatsBar({ stats }) {
  const cards = [
    { label: 'Total Tasks',  value: stats.total,    color: 'var(--text)',   emoji: '📋' },
    { label: 'To Do',        value: stats.todo,     color: 'var(--blue)',   emoji: '🕐' },
    { label: 'In Progress',  value: stats.progress, color: 'var(--orange)', emoji: '⚡' },
    { label: 'Completed',    value: stats.done,     color: 'var(--accent)', emoji: '✅' },
  ];

  return (
    <div className="stats-bar">
      {cards.map((c, i) => (
        <div className="stat-card" key={i} style={{ '--c': c.color }}>
          <div className="stat-top">
            <span className="stat-val">{c.value}</span>
            <span className="stat-emoji">{c.emoji}</span>
          </div>
          <p className="stat-lbl">{c.label}</p>
          <div className="stat-line"><div className="stat-fill" /></div>
        </div>
      ))}
    </div>
  );
}
