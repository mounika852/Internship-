import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import StatsBar from './components/StatsBar';
import Toolbar from './components/Toolbar';
import Board from './components/Board';
import TaskModal from './components/TaskModal';
import Toast from './components/Toast';
import './App.css';

// ── helpers ───────────────────────────────────────────────────────
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2);

const SEED = [
  { id: uid(), title: 'Set up MongoDB connection',    description: 'Configure mongoose and connect to Atlas cluster.',         status: 'completed',   priority: 'high',   createdAt: new Date(Date.now() - 5 * 86400000).toISOString() },
  { id: uid(), title: 'Build REST API endpoints',     description: 'CRUD operations for tasks using Express.js routes.',      status: 'completed',   priority: 'high',   createdAt: new Date(Date.now() - 4 * 86400000).toISOString() },
  { id: uid(), title: 'Design React UI components',   description: 'Build Kanban board, task cards, and modal forms.',        status: 'in-progress', priority: 'high',   createdAt: new Date(Date.now() - 2 * 86400000).toISOString() },
  { id: uid(), title: 'JWT Authentication',           description: 'Implement login/register with bcrypt and JWT tokens.',    status: 'in-progress', priority: 'medium', createdAt: new Date(Date.now() - 1 * 86400000).toISOString() },
  { id: uid(), title: 'Add drag and drop support',    description: 'Allow tasks to be moved between columns via drag.',       status: 'todo',        priority: 'medium', createdAt: new Date().toISOString() },
  { id: uid(), title: 'Write unit tests',             description: 'Test all API routes and React components with Jest.',     status: 'todo',        priority: 'low',    createdAt: new Date().toISOString() },
  { id: uid(), title: 'Deploy to production',         description: 'Host backend on Render and frontend on Vercel.',         status: 'todo',        priority: 'medium', createdAt: new Date().toISOString() },
];

export default function App() {
  const [tasks,         setTasks]         = useState(() => {
    const saved = localStorage.getItem('taskflow_v2');
    return saved ? JSON.parse(saved) : SEED;
  });
  const [modal,         setModal]         = useState({ open: false, task: null, defaultStatus: 'todo' });
  const [toasts,        setToasts]        = useState([]);
  const [filter,        setFilter]        = useState('all');
  const [priorityFilter,setPriorityFilter]= useState(null);
  const [search,        setSearch]        = useState('');

  // persist
  useEffect(() => { localStorage.setItem('taskflow_v2', JSON.stringify(tasks)); }, [tasks]);

  // keyboard shortcut
  useEffect(() => {
    const onKey = e => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); openModal(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // ── toast ────────────────────────────────────────────────────────
  const toast = useCallback((msg, type = 'info') => {
    const id = uid();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 2800);
  }, []);

  // ── task actions ──────────────────────────────────────────────────
  const openModal  = (defaultStatus = 'todo', task = null) => setModal({ open: true, task, defaultStatus });
  const closeModal = () => setModal({ open: false, task: null, defaultStatus: 'todo' });

  const saveTask = (data) => {
    if (modal.task) {
      setTasks(p => p.map(t => t.id === modal.task.id ? { ...t, ...data, updatedAt: new Date().toISOString() } : t));
      toast('Task updated ✓', 'success');
    } else {
      setTasks(p => [{ ...data, id: uid(), createdAt: new Date().toISOString() }, ...p]);
      toast('Task created ✓', 'success');
    }
    closeModal();
  };

  const deleteTask = (id) => {
    setTasks(p => p.filter(t => t.id !== id));
    toast('Task deleted', 'info');
  };

  const moveTask = (id, status) => {
    setTasks(p => p.map(t => t.id === id ? { ...t, status, updatedAt: new Date().toISOString() } : t));
    const labels = { todo: 'Moved to To Do', 'in-progress': 'In Progress ⚡', completed: 'Marked complete ✓' };
    toast(labels[status], 'success');
  };

  const clearCompleted = () => {
    const count = tasks.filter(t => t.status === 'completed').length;
    if (!count) { toast('No completed tasks', 'info'); return; }
    setTasks(p => p.filter(t => t.status !== 'completed'));
    toast(`${count} task${count > 1 ? 's' : ''} cleared`, 'info');
  };

  // ── filtered tasks ────────────────────────────────────────────────
  const filtered = tasks.filter(t => {
    if (filter !== 'all' && t.status !== filter) return false;
    if (priorityFilter && t.priority !== priorityFilter) return false;
    if (search && !t.title.toLowerCase().includes(search.toLowerCase()) &&
        !(t.description || '').toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const stats = {
    total:    tasks.length,
    todo:     tasks.filter(t => t.status === 'todo').length,
    progress: tasks.filter(t => t.status === 'in-progress').length,
    done:     tasks.filter(t => t.status === 'completed').length,
  };

  return (
    <div className="app-layout">
      <Sidebar
        stats={stats}
        filter={filter}
        setFilter={v => { setFilter(v); setPriorityFilter(null); }}
        priorityFilter={priorityFilter}
        setPriorityFilter={v => { setPriorityFilter(v); setFilter('all'); }}
      />
      <div className="app-main">
        <Header onNew={() => openModal()} onClearDone={clearCompleted} />
        <StatsBar stats={stats} />
        <Toolbar
          search={search}
          setSearch={setSearch}
          filter={filter}
          setFilter={v => { setFilter(v); setPriorityFilter(null); }}
        />
        <Board
          tasks={filtered}
          onEdit={(task) => openModal(task.status, task)}
          onDelete={deleteTask}
          onMove={moveTask}
          onAdd={(status) => openModal(status)}
        />
      </div>

      {modal.open && (
        <TaskModal
          task={modal.task}
          defaultStatus={modal.defaultStatus}
          onSave={saveTask}
          onClose={closeModal}
        />
      )}

      <div className="toast-stack">
        {toasts.map(t => <Toast key={t.id} msg={t.msg} type={t.type} />)}
      </div>
    </div>
  );
}
